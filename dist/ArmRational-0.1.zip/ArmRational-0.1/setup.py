from distutils.core import setup

setup(
    name='ArmRational',
    version='0.1',
    packages=[''],
    url='www.sparta.am',
    license='MIT',
    author='Sparta',
    author_email='sparta@sparta.am',
    description='Implementation of ration class'
)
